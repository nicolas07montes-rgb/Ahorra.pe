// Uso (en tu computadora, con Node 18 o superior):  node bajar-fotos.js
// Lee las URL de index.html, abre cada página de la tienda, descarga su imagen principal (og:image)
// a la carpeta img/ y crea fotos.json. Sube index.html, fotos.json y la carpeta img/ a GitHub.
const fs = require('fs'), vm = require('vm');
const html = fs.readFileSync('index.html', 'utf8');
const code = html.slice(html.indexOf('const FB='), html.indexOf('const TIENDAS')) + ';PRODUCTOS';
const productos = vm.runInNewContext(code);
const urls = [...new Set(productos.flatMap(p => p.ofertas.map(o => o.url)))];
const mapa = fs.existsSync('fotos.json') ? JSON.parse(fs.readFileSync('fotos.json', 'utf8')) : {};
fs.mkdirSync('img', { recursive: true });
const UA = { 'User-Agent': 'Mozilla/5.0 (compatible; AhorraPeBot/1.0)', 'Accept-Language': 'es-PE,es;q=0.9' };
const espera = ms => new Promise(r => setTimeout(r, ms));
function og(h, base) {
  const m = h.match(/<meta[^>]+(?:property|name)=["']og:image["'][^>]*content=["']([^"']+)["']/i) ||
            h.match(/<meta[^>]+content=["']([^"']+)["'][^>]*(?:property|name)=["']og:image["']/i);
  return m ? new URL(m[1].replace(/&amp;/g, '&'), base).href : null;
}
(async () => {
  let n = 0;
  for (const url of urls) {
    if (mapa[url] && fs.existsSync(mapa[url])) continue;
    try {
      const r = await fetch(url, { headers: UA, redirect: 'follow' });
      if (!r.ok) throw new Error('HTTP ' + r.status);
      const src = og(await r.text(), url);
      if (!src) throw new Error('sin imagen og:image');
      const ir = await fetch(src, { headers: UA });
      if (!ir.ok) throw new Error('imagen HTTP ' + ir.status);
      const tipo = ir.headers.get('content-type') || '';
      const ext = tipo.includes('png') ? 'png' : tipo.includes('webp') ? 'webp' : 'jpg';
      const nombre = 'img/' + String(++n + Object.keys(mapa).length).padStart(3, '0') + '.' + ext;
      fs.writeFileSync(nombre, Buffer.from(await ir.arrayBuffer()));
      mapa[url] = nombre;
      console.log('OK   ', url);
    } catch (e) { console.log('FALLÓ', url, '→', e.message); }
    await espera(1500);
  }
  fs.writeFileSync('fotos.json', JSON.stringify(mapa, null, 1));
  console.log('Listo. Fotos guardadas:', Object.keys(mapa).length, 'de', urls.length);
})();
